import React, { useState } from "react";
import PlacementForm from "../components/PlacementForm";
import { schedulePlacement } from "../api/api";

export default function SchedulePlacementPage() {
  const [message, setMessage] = useState("");

  const handleSchedule = async (data) => {
    try {
      await schedulePlacement(data);
      setMessage("Placement scheduled successfully!");
    } catch (e) {
      setMessage("Error scheduling placement.");
    }
  };

  return (
    <div>
      <PlacementForm onSubmit={handleSchedule} />
      {message && <p>{message}</p>}
    </div>
  );
}
