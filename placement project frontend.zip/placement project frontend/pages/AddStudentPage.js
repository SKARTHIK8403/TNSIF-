import React, { useState, useEffect } from "react";
import LoginForm from "../components/LoginForm";
import StudentForm from "../components/StudentForm";
import StudentList from "../components/StudentList";
import {
  fetchStudents,
  addStudent,
  updateStudent,
  deleteStudent,
  login,
} from "../api/api";

export default function AddStudentPage() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [students, setStudents] = useState([]);
  const [editStudent, setEditStudent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    if (loggedIn) loadStudents();
  }, [loggedIn]);

  async function loadStudents() {
    setLoading(true);
    try {
      const res = await fetchStudents();
      setStudents(res.data);
    } catch (e) {
      setErrorMsg("Failed to load students");
    }
    setLoading(false);
  }

  const handleLoginSuccess = (username, msg) => {
    setLoggedIn(true);
    setUserRole(msg); // You can parse role from msg if structured better
    setErrorMsg("");
  };

  const handleAddOrUpdateStudent = async (studentData) => {
    try {
      if (editStudent) {
        await updateStudent(editStudent.id, studentData);
        setEditStudent(null);
      } else {
        await addStudent(studentData);
      }
      loadStudents();
    } catch (e) {
      alert("Error saving student data");
    }
  };

  const handleEdit = (student) => setEditStudent(student);
  const handleCancelEdit = () => setEditStudent(null);

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure to delete this student?")) return;
    try {
      await deleteStudent(id);
      loadStudents();
    } catch {
      alert("Failed to delete student");
    }
  };

  if (!loggedIn) {
    return <LoginForm onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div>
      <h2>Add / Manage Students</h2>
      {errorMsg && <p style={{ color: "red" }}>{errorMsg}</p>}
      <StudentForm
        onSubmit={handleAddOrUpdateStudent}
        editData={editStudent}
        onCancel={handleCancelEdit}
      />
      {loading ? <p>Loading...</p> : null}
      <StudentList students={students} onEdit={handleEdit} onDelete={handleDelete} />
    </div>
  );
}
