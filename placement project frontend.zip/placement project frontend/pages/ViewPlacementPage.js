import React, { useState, useEffect } from "react";
import PlacementList from "../components/PlacementList";
import { getAllSchedules } from "../api/api";

export default function ViewPlacementPage() {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    loadSchedules();
  }, []);

  async function loadSchedules() {
    setLoading(true);
    try {
      const res = await getAllSchedules();
      setSchedules(res.data);
    } catch (e) {
      console.error("Error fetching placements:", e);
      setErrorMsg("Failed to load placement drives.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h2>Placement Drives List</h2>
      {errorMsg && <p style={{ color: "red" }}>{errorMsg}</p>}
      {loading ? <p>Loading...</p> : <PlacementList schedules={schedules} />}
    </div>
  );
}
