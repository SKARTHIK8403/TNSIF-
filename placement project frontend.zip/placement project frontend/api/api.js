import axios from "axios";

const API_BASE = "http://localhost:8080";

const api = axios.create({
  baseURL: API_BASE,
});

// Auth login
export const login = (username, password) =>
  api.post("/auth/login", { username, password });

// Students CRUD
export const fetchStudents = () => api.get("/student/search?query=");
export const addStudent = (student) => api.post("/student/add", student);
export const updateStudent = (id, student) =>
  api.put(`/student/update/${id}`, student);
export const deleteStudent = (id) => api.delete(`/student/delete/${id}`);

// Placement drives
export const schedulePlacement = (schedule) =>
  api.post("/placement/schedule", schedule);

export function getAllSchedules() {
  return api.get("/placement/all");
}

export default api;
