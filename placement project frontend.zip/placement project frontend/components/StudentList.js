import React from "react";

export default function StudentList({ students, onEdit, onDelete }) {
  return (
    <div>
      <h3>Registered Students</h3>
      {students.length === 0 && <p>No students registered yet.</p>}
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Name</th>
            <th>Qualification</th>
            <th>Course</th>
            <th>Year</th>
            <th>Hall Ticket</th>
            <th>Certificate</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.studentName}</td>
              <td>{s.qualification}</td>
              <td>{s.course}</td>
              <td>{s.yearOfPassing}</td>
              <td>{s.hallTicketNumber}</td>
              <td>{s.certificate}</td>
              <td>
                <button onClick={() => onEdit(s)}>Edit</button>
                <button onClick={() => onDelete(s.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
