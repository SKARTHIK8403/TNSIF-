import React from "react";

export default function PlacementList({ schedules }) {
  if (!schedules.length) {
    return <p>No placement drives found.</p>;
  }

  return (
    <div>
      <h2>Placement Drives</h2>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Date</th>
            <th>Qualification</th>
            <th>Year</th>
            <th>University</th>
            <th>Company</th>
          </tr>
        </thead>
        <tbody>
          {schedules.map((p, idx) => (
            <tr key={idx}>
              <td>{p.scheduleDate}</td>
              <td>{p.qualification}</td>
              <td>{p.year}</td>
              <td>{p.university}</td>
              <td>{p.company}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
