import React, { useState, useEffect } from "react";

export default function StudentForm({ onSubmit, editData, onCancel }) {
  const [studentName, setStudentName] = useState("");
  const [qualification, setQualification] = useState("");
  const [course, setCourse] = useState("");
  const [yearOfPassing, setYearOfPassing] = useState("");
  const [hallTicketNumber, setHallTicketNumber] = useState("");
  const [certificate, setCertificate] = useState("");

  useEffect(() => {
    if (editData) {
      setStudentName(editData.studentName);
      setQualification(editData.qualification);
      setCourse(editData.course);
      setYearOfPassing(editData.yearOfPassing);
      setHallTicketNumber(editData.hallTicketNumber);
      setCertificate(editData.certificate);
    } else {
      setStudentName("");
      setQualification("");
      setCourse("");
      setYearOfPassing("");
      setHallTicketNumber("");
      setCertificate("");
    }
  }, [editData]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      studentName,
      qualification,
      course,
      yearOfPassing,
      hallTicketNumber,
      certificate,
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>{editData ? "Edit Student" : "Add Student"}</h3>
      <label>Name:</label>
      <input
        type="text"
        value={studentName}
        onChange={(e) => setStudentName(e.target.value)}
        required
      />
      <label>Qualification:</label>
      <input
        type="text"
        value={qualification}
        onChange={(e) => setQualification(e.target.value)}
      />
      <label>Course:</label>
      <input type="text" value={course} onChange={(e) => setCourse(e.target.value)} />
      <label>Year Of Passing:</label>
      <input
        type="number"
        value={yearOfPassing}
        onChange={(e) => setYearOfPassing(e.target.value)}
      />
      <label>Hall Ticket Number:</label>
      <input
        type="text"
        value={hallTicketNumber}
        onChange={(e) => setHallTicketNumber(e.target.value)}
        required
      />
      <label>Certificate:</label>
      <input
        type="text"
        value={certificate}
        onChange={(e) => setCertificate(e.target.value)}
      />
      <button type="submit">{editData ? "Update" : "Add"}</button>
      {editData && <button onClick={onCancel}>Cancel</button>}
    </form>
  );
}
