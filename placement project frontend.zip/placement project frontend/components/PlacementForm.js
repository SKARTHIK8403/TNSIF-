import React, { useState } from "react";
import axios from "axios";

export default function SchedulePlacement() {
  const [form, setForm] = useState({
    scheduleDate: "",
    qualification: "",
    year: "",
    university: "",
    company: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8080/placement/schedule", form);
      alert("Placement scheduled successfully.");
      setForm({ scheduleDate: "", qualification: "", year: "", university: "", company: "" });
    } catch (error) {
      alert("Failed to schedule placement.");
    }
  };

  return (
    <div>
      <h2>Schedule Placement</h2>
      <form onSubmit={handleSubmit}>
        <input name="scheduleDate" type="date" value={form.scheduleDate} onChange={handleChange} required /><br />
        <input name="qualification" placeholder="Qualification" value={form.qualification} onChange={handleChange} required /><br />
        <input name="year" type="number" placeholder="Year" value={form.year} onChange={handleChange} required /><br />
        <input name="university" placeholder="University" value={form.university} onChange={handleChange} required /><br />
        <input name="company" placeholder="Company" value={form.company} onChange={handleChange} required /><br />
        <button type="submit">Schedule</button>
      </form>
    </div>
  );
}
