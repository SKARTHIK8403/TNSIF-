import React from "react";
import { NavLink } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
        Home
      </NavLink>
      <NavLink to="/add-student" className={({ isActive }) => (isActive ? "active" : "")}>
        Add Student
      </NavLink>
      <NavLink to="/schedule-placement" className={({ isActive }) => (isActive ? "active" : "")}>
        Schedule Placement Drive
      </NavLink>
      <NavLink to="/view-placement" className={({ isActive }) => (isActive ? "active" : "")}>
        View Placement Drives
      </NavLink>
    </nav>
  );
}
