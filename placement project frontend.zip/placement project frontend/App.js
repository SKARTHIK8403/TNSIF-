import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import AddStudentPage from "./pages/AddStudentPage";
import SchedulePlacementPage from "./pages/SchedulePlacementPage";
import ViewPlacementPage from "./pages/ViewPlacementPage";

// Home component with instructions and styling
function Home() {
  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Welcome to the Placement Portal</h1>
      <p style={styles.intro}>
        This portal helps manage all campus placement activities efficiently for both students and administrators.
      </p>

      <div style={styles.instructions}>
        <h2 style={styles.subheading}>You can do the following here:</h2>
        <ul>
          <li>📄 <strong>Add Students</strong> to the placement database.</li>
          <li>📅 <strong>Schedule Placement Drives</strong> for companies.</li>
          <li>🔍 <strong>View All Scheduled Drives</strong> with dates, qualifications, and company details.</li>
        </ul>
      </div>

      <div style={styles.footer}>
        <p>Use the navigation bar above to explore these features.</p>
        <p>Contact admin for technical support or issues.</p>
      </div>
    </div>
  );
}

// Main App component with routing
export default function App() {
  return (
    <Router>
      <Navbar />
      <div className="container" style={{ padding: "20px" }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/add-student" element={<AddStudentPage />} />
          <Route path="/schedule-placement" element={<SchedulePlacementPage />} />
          <Route path="/view-placement" element={<ViewPlacementPage />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </Router>
  );
}

// Styling object
const styles = {
  container: {
    padding: "40px",
    fontFamily: "'Segoe UI', sans-serif",
    backgroundColor: "#f9f9f9",
    color: "#333",
    minHeight: "80vh",
  },
  heading: {
    fontSize: "2.5rem",
    color: "#0a4f8a",
    marginBottom: "20px",
  },
  intro: {
    fontSize: "1.2rem",
    marginBottom: "30px",
  },
  instructions: {
    backgroundColor: "#ffffff",
    padding: "20px",
    borderRadius: "10px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
    marginBottom: "30px",
  },
  subheading: {
    fontSize: "1.5rem",
    color: "#0a4f8a",
    marginBottom: "15px",
  },
  footer: {
    fontSize: "1rem",
    color: "#555",
  },
};
