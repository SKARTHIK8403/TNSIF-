package com.example.demo;

import jakarta.persistence.*;

@Entity
@Table(name = "students")

public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "student_name")
    private String studentName;

    @Column(name = "qualification")
    private String qualification;

    @Column(name = "course")
    private String course;

    @Column(name = "year_of_passing")
    private int yearOfPassing;

    @Column(name = "hall_ticket_number", unique = true)
    private String hallTicketNumber;

    @Column(name = "certificate")
    private String certificate;
    public Student() {
    	
    }

	public Student(Long id, String studentName, String qualification, String course, int yearOfPassing,
			String hallTicketNumber, String certificate) {		
		this.id = id;
		this.studentName = studentName;
		this.qualification = qualification;
		this.course = course;
		this.yearOfPassing = yearOfPassing;
		this.hallTicketNumber = hallTicketNumber;
		this.certificate = certificate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public int getYearOfPassing() {
		return yearOfPassing;
	}

	public void setYearOfPassing(int yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}

	public String getHallTicketNumber() {
		return hallTicketNumber;
	}

	public void setHallTicketNumber(String hallTicketNumber) {
		this.hallTicketNumber = hallTicketNumber;
	}

	public String getCertificate() {
		return certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", studentName=" + studentName + ", qualification=" + qualification + ", course="
				+ course + ", yearOfPassing=" + yearOfPassing + ", hallTicketNumber=" + hallTicketNumber
				+ ", certificate=" + certificate + "]";
	}
    
    
    
}
