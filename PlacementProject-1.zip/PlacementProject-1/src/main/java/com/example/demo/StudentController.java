package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentRepository studentRepo;

    // University posts student data
    @PostMapping("/add")
    public ResponseEntity<String> addStudent(@RequestBody Student student) {
        try {
            studentRepo.save(student);
            return ResponseEntity.ok("Student data added successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error saving student data.");
        }
    }

    // Corporate downloads certificate
    @GetMapping("/certificate")
    public ResponseEntity<String> getCertificate(
            @RequestParam String studentName,
            @RequestParam String hallTicketNumber) {

        Optional<Student> student = studentRepo.findByStudentNameAndHallTicketNumber(studentName, hallTicketNumber);
        
        return student.map(value -> ResponseEntity.ok(value.getCertificate()))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body("Certificate not found."));
    }
    
}
