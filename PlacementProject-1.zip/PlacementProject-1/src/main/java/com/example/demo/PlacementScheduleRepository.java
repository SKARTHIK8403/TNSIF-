package com.example.demo;


import org.springframework.data.jpa.repository.JpaRepository;

public interface PlacementScheduleRepository extends JpaRepository<PlacementSchedule, Long> {
}
