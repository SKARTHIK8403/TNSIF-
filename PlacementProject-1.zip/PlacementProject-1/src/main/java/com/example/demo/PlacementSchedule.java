package com.example.demo;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "placement_schedule")
public class PlacementSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "schedule_date", nullable = false)
    private LocalDate scheduleDate;

    @Column(nullable = false)
    private String qualification;

    @Column(nullable = false)
    private int year;

    @Column(nullable = false)
    private String university;

    @Column(nullable = false)
    private String company;

    // Getters and Setters
    public Long getId() { return id; }

    public LocalDate getScheduleDate() { return scheduleDate; }
    public void setScheduleDate(LocalDate scheduleDate) { this.scheduleDate = scheduleDate; }

    public String getQualification() { return qualification; }
    public void setQualification(String qualification) { this.qualification = qualification; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public String getUniversity() { return university; }
    public void setUniversity(String university) { this.university = university; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
}