package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class UserController {
  @Autowired private UserRepository repo;

  @PostMapping("/login")
  public ResponseEntity<String> login(@RequestBody User user) {
    return repo.findByUsernameAndPassword(user.getUsername(), user.getPassword())
      .map(u -> ResponseEntity.ok("Login successful for: " + u.getRole()))
      .orElse(ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials"));
  }
}

